package service.impl;

import service.ITeacherService;

public class TeacherService implements ITeacherService {
}
