package service;

public interface ITeacherService {
}
